import os, re, time, docx, faiss, base64, tempfile
import numpy as np
import streamlit as st
import matplotlib.pyplot as plt
import pandas as pd

from gtts import gTTS
from io import BytesIO
from collections import defaultdict, Counter
from sentence_transformers import SentenceTransformer, CrossEncoder
from llama_cpp import Llama
from langdetect import detect
from googletrans import Translator
from rank_bm25 import BM25Okapi
import speech_recognition as sr
import openai
import sys
import types

# Patch for torch.classes path error on macOS + Streamlit
import torch
if not hasattr(torch, '__path__'):
    torch.__path__ = types.SimpleNamespace(_path=[])

# === Load and Chunk ERP DOCX ===
@st.cache_data
def load_erp_chunks(path):
    doc = docx.Document(path)
    paras = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
    chunks, title, buf = [], "", []
    for para in paras:
        if para.isupper() and len(para.split()) < 10:
            if title and buf:
                chunks.append(title + "\n" + "\n".join(buf))
            title, buf = para, []
        else:
            buf.append(para)
            if len(buf) >= 5:
                chunks.append(title + "\n" + "\n".join(buf))
                buf = []
    if title and buf:
        chunks.append(title + "\n" + "\n".join(buf))
    return chunks

# === Build Embedding Index (FAISS + BM25) ===
@st.cache_resource
def build_indexes(chunks):
    embedder = SentenceTransformer("all-MiniLM-L6-v2")
    embeddings = embedder.encode(chunks, show_progress_bar=True)
    faiss_index = faiss.IndexFlatL2(embeddings[0].shape[0])
    faiss_index.add(np.array(embeddings))
    tokenized = [c.lower().split() for c in chunks]
    bm25 = BM25Okapi(tokenized)
    return faiss_index, embeddings, embedder, bm25, tokenized


# ✅ Set OpenRouter API Key
OPENROUTER_API_KEY = "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"  # your actual key

import requests

@st.cache_resource
def load_openrouter_llm():
    def call_openrouter(prompt, temperature=0.3, top_p=0.8, max_tokens=1024):
        headers = {
            "Authorization": f"Bearer {OPENROUTER_API_KEY}",  # Replace with your valid OpenRouter key
            "Content-Type": "application/json"
        }
        body = {
            "model": "openai/gpt-4o",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
            "top_p": top_p,
            "max_tokens": max_tokens
        }

        try:
            response = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=body)
            result = response.json()
            print("🔍 OpenRouter raw response:", result)  # Debug
            return result["choices"][0]["message"]["content"].strip()
        except Exception as e:
            return f"[OpenRouter Error] {str(e)}"

    return call_openrouter




# === Translate Helper ===
def translate_to_en(text):
    try:
        return Translator().translate(text, dest='en').text
    except:
        return text

def translate_back(text, dest_lang):
    try:
        return Translator().translate(text, dest=dest_lang).text
    except:
        return text

# === Text-to-Speech (gTTS) ===
def speak_gtts(text):
    tts = gTTS(text, lang='en', tld='com')
    with tempfile.NamedTemporaryFile(delete=False, suffix=".mp3") as tmp:
        tts.save(tmp.name)
        audio = open(tmp.name, 'rb').read()
        b64 = base64.b64encode(audio).decode()
        st.markdown(f'<audio autoplay controls><source src="data:audio/mp3;base64,{b64}" type="audio/mp3"></audio>', unsafe_allow_html=True)

# === Voice to Text ===
def voice_to_text():
    r = sr.Recognizer()
    with sr.Microphone() as src:
        st.info("🎙️ Listening... Speak your question")
        audio = r.listen(src, timeout=10)
        try:
            return r.recognize_google(audio)
        except:
            return ""

# === RAG + Reranking + LLM ===
def generate_response(query, chunks, embeddings, faiss_index, embedder, bm25, tokenized, llm, cross_encoder):
    start = time.time()
    original_lang = detect(query)
    en_query = translate_to_en(query) if original_lang != "en" else query

    q_embed = embedder.encode([en_query])
    _, I = faiss_index.search(np.array(q_embed), k=5)
    bm25_scores = bm25.get_scores(en_query.lower().split())
    hybrid_scores = {i: 0.7*(1 - faiss_index.reconstruct(i).dot(q_embed[0])) + 0.3*bm25_scores[i] for i in range(len(chunks))}
    top_idxs = sorted(I[0], key=lambda i: hybrid_scores.get(i, 1e6))[:5]

    rerank_inputs = [[en_query, chunks[i]] for i in top_idxs]
    rerank_scores = cross_encoder.predict(rerank_inputs)
    reranked = [x for _, x in sorted(zip(rerank_scores, top_idxs), reverse=True)]

    selected = []
    context, tokens = "", 0
    for i in reranked:
        t = int(len(chunks[i].split()) * 1.3)
        if tokens + t > 1400: break
        selected.append(i)
        context += chunks[i].strip() + "\n\n"
        tokens += t

    prompt = f"[INST] Use only the context to answer clearly and helpfully.\n\nContext:\n{context}\n\nQuestion: {en_query}\nAnswer: [/INST]"
    answer = llm(prompt, temperature=0.3, top_p=0.8, max_tokens=1024)



    answer = answer[:answer.rfind(".")+1] if answer and answer[-1] not in ".!?" else answer
    translated_answer = translate_back(answer, original_lang) if original_lang != "en" else answer

    # Related Questions
    follow_prompt = f"[INST] Suggest 3 helpful follow-up questions for this ERP query:\n\n{en_query} [/INST]"
    suggestions = llm(follow_prompt, temperature=0.3, top_p=0.8, max_tokens=256)


    followups = [q.strip("-• ") for q in suggestions.split("\n") if q.strip()][:3]

    # Hallucination detection
    overlap = sum(1 for w in answer.lower().split() if any(w in c.lower() for c in [chunks[i] for i in selected]))
    risk = "Low" if overlap > 10 else "Moderate" if overlap > 5 else "High"

    latency = round(time.time() - start, 2)
    relevance = round(max(rerank_scores), 3)

    return translated_answer, [chunks[i] for i in selected], relevance, latency, followups, risk

# === Streamlit UI ===
st.set_page_config(page_title="ERP-GeniusBot", layout="wide")
st.title("ERP-GeniusBot: A Multilingual, Voice-Enabled ERP-LLM for Business Optimization Using Hybrid RAG and OpenRouter LLM")


erp_tools = ["None", "Acumatica", "IFS Applications", "Infor CloudSuite Industrial", "Odoo", "Oracle NetSuite", "SAP Business ByDesign", "SAP Business One"]
tool = st.sidebar.selectbox("Browse ERP Tool", erp_tools)

query = ""
if st.button("🎙️ Voice Search"):
    query = voice_to_text()
else:
    query = st.text_input("💬 Ask an ERP-related question:")

if tool != "None":
    query = f"Give summary of {tool} in 5 lines"

data_store = st.session_state.setdefault("history", [])
tool_counter = st.session_state.setdefault("tool_queries", defaultdict(int))

if query:
    chunks = load_erp_chunks("erpdata.docx")
    faiss_index, embeddings, embedder, bm25, tokenized = build_indexes(chunks)
    llm = load_openrouter_llm()
    cross_encoder = CrossEncoder("cross-encoder/ms-marco-MiniLM-L-6-v2")

    with st.spinner("🤖 Thinking..."):
        answer, retrieved, score, latency, followups, risk = generate_response(query, chunks, embeddings, faiss_index, embedder, bm25, tokenized, llm, cross_encoder)

    st.markdown("### ✅ Answer")
    st.success(answer)

    if st.button("🔊 Read Out"):
        speak_gtts(answer)

    with st.expander("📄 Retrieved Context"):
        for c in retrieved:
            st.code(c)

    st.markdown("### 📈 Evaluation")
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Words", len(answer.split()))
    col2.metric("Relevance", score)
    col3.metric("Latency", f"{latency}s")
    col4.metric("Hallucination Risk", risk)

    st.markdown("### 🧠 Related Questions")
    for q in followups:
        st.markdown(f"- {q}")

    feedback = st.radio("Was this helpful?", ["👍", "👎"], key=query)

    # Save log
    tool_match = next((t for t in erp_tools if t.lower() in query.lower()), "None")
    if tool_match != "None":
        tool_counter[tool_match] += 1
    data_store.append({"query": query, "answer": answer, "tool": tool_match, "relevance": score, "latency": latency, "feedback": feedback})

st.sidebar.markdown("---")
st.sidebar.header("📊 Dashboard")

if data_store:
    st.sidebar.markdown(f"**Total Queries:** {len(data_store)}")
    if tool_counter:
        fig, ax = plt.subplots()
        labels, values = zip(*tool_counter.items())
        ax.pie(values, labels=labels, autopct='%1.1f%%', startangle=90, colors=plt.cm.tab20.colors)
        ax.axis("equal")
        st.sidebar.pyplot(fig)

    if st.sidebar.button("📥 Export Logs"):
        pd.DataFrame(data_store).to_csv("erp_chat_log.csv", index=False)
        st.sidebar.success("Exported to erp_chat_log.csv")
